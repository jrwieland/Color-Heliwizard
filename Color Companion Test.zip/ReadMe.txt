This supplied companion is compiled for the Radiomaster TX16S
Extract the files.

Use the supplied companion it has been compiled with the firmware changes to access the swash settings.

If another version of companion is used for testing the Flybar Helicopter Setup - 
you will receive the following error:
Script error: /SCRIPTS/WIZARD/heli/wizard.lua:548: attempt to call field 'swashRingData' (a nil value)

open settings in companion, point the sd location to where you extracted the zip file
there is a folder called "sdcard-tx16s" this is a stripped down SD card for testing.

Create a new model.
click simulate
click sys
page right (sd card)
scroll down to scripts <enter>
scroll down to wizard <enter>
 scroll down to heli <enter>
click on wizard.lua 

try various setups and let me know your thoughts

Send Feedback to: 
john.r.wieland@gmail.com
or
send me a DM on Discord
Jrwieland#9849